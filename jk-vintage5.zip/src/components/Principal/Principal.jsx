import React from 'react'

const Principal = () => {
    return (
        <div>
            first page
        </div>
    )
}

export default Principal