import { makeStyles } from '@material-ui/core/styles';

export default makeStyles((theme) => ({
  toolbar: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    backgroundColor: '#eee5e9',
    padding: theme.spacing(6),
  },
  root: {
    flexGrow: 1,
  },
  logoImage: {
    width: '50%'
  },
  lastDrop: {
    position: 'relative',
    left: '50%',
    transform: 'translatex(-50%)'
  }
}));