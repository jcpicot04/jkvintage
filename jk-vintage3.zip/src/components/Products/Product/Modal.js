import React, { useRef, useEffect, useCallback, useState } from 'react';
import { useSpring, animated } from 'react-spring';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import { MdClose } from 'react-icons/md';
import { Button } from '@material-ui/core';


const Background = styled.div`
width: 120%;
height: 0;
left: -10%;
right: 60%;
backgroundColor: white;
position: relative;
display: flex;
justify-content: center;
align-items: center;
text-align: center;
margin-bottom: 0px;
bottom: 300px;
box-shadow: 5px 5px 0px 0px #289FED, 10px 10px 0px 0px #5FB8FF, 15px 15px 0px 0px #A1D8FF, 20px 20px 0px 0px #CAE6FF, 25px 25px 0px 0px #E1EEFF, 5px 5px 15px 5px rgba(94,38,255,0);z-index: 1000;
filter: blur(-3px);
`;

const ModalWrapper = styled.div`
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #D1C5DA;
  color: #000;
  display: grid;
  grid-template-columns: 1fr 1fr;
  position: relative;
  z-index: 10;
  border-radius: 10px;
  box-shadow: 0px 0px 24px -4px rgba(209,123,230,0.75);
  -webkit-box-shadow: 0px 0px 24px -4px rgba(209,123,230,0.75);
  -moz-box-shadow: 0px 0px 24px -4px rgba(209,123,230,0.75);

`;

const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-left: 280px;
  padding-right: 20px;
  padding-bottom: 20px;
  align-items: center;
  line-height: 1.2;
  color: #141414;
  p {
    margin-bottom: 1rem;
  }
  button {
    padding: 10px 24px;
    background: #141414;
    color: #fff;
    border: none;
  }
`;

const CloseModalButton = styled(MdClose)`
  cursor: pointer;
  position: absolute;
  top: 20px;
  right: 20px;
  width: 32px;
  height: 32px;
  padding: 0;
  z-index: 10;
`;

const Modal = ({showModal,setShowModal, product, onAddToCart, setBlurBackground, myRef}) => {
    const modalRef = useRef();
    const [load, setLoad] = useState(false);

    function createMarkup() {
        return { __html: product.description };
      }
  const animation = useSpring({
    config: {
      duration: 250
    },
    opacity: showModal ? 1 : 0,
    transform: showModal ? `translateY(0%)` : `translateY(-100%)`
  });

  const closeModal = e => {
    if (modalRef.current === e.target) {
      setShowModal(false);
    }
  };

  const keyPress = useCallback(
    e => {
      if (e.key === 'Escape' && showModal) {
        setShowModal(false);
      }
    },
    [setShowModal, showModal]
  );

  const setScroll = () => {
    document.body.style.overflow = "scroll";
    const blockBack = document.getElementsByClassName('MuiCard-root');

    for (var i=0; i<blockBack.length; i++) {
        blockBack[i].style.pointerEvents = "all";
    }
  };

  useEffect(
    () => {
      document.addEventListener('keydown', keyPress);
      return () => document.removeEventListener('keydown', keyPress);
    },
    [keyPress]
  );

  return (
    <>
      {showModal ? (
        <Background onClick={closeModal} ref={modalRef} id="modal">
          <animated.div style={animation}>
            <ModalWrapper showModal={showModal} ref={myRef}>
              <img src={product.media.source} alt='camera' style={{width: "70%", top: "20%", right:"38%", position: "absolute"}}/>
              <ModalContent>
                <h1 style={{marginRight: '150%'}}>{product.name}</h1>
                <p dangerouslySetInnerHTML={createMarkup()}></p>
                <Button component={Link} to="/cart" variant="outlined" disabled={load} onClick={() => {setScroll(); setLoad(true); onAddToCart(product.id, 1).then(() => setLoad(false))}} style={{cursor: "pointer"}}>Comprar</Button>
              </ModalContent>
              <CloseModalButton
                aria-label='Cerrar detalles'
                onClick={() => { setShowModal(prev => !prev); setBlurBackground(prev => !prev); setScroll()}}
              />
            </ModalWrapper>
          </animated.div>
        </Background>
      ) : null}
    </>
  );
};

export default Modal
