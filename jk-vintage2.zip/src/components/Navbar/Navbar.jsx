import React, { useState } from 'react';
import { AppBar, Toolbar, IconButton, Badge, Typography, Input} from '@material-ui/core';
import {ShoppingCart} from '@material-ui/icons';
import { Link, useLocation } from 'react-router-dom';
import logo from '../../assets/jkvintage.png';
import useStyles from './styles';

const Navbar = ({ totalItems, setvalueSearch }) => {
    const classes = useStyles();
    const location = useLocation();
    return (
        <AppBar position='fixed' className={classes.appBar} color="inherit">
            <Toolbar>
                <Typography component={Link} to="/" variant="h6" className={classes.title} color="inherit">
                    <img src={logo} alt="JK Vintage" height="25px" className={classes.image} />
                    JK Vintage
                </Typography>
                {location.pathname === '/' && (
                <Input
            type="search"
            placeholder="Buscar por marca..."
            onChange={(e) => setvalueSearch(e.target.value)}
            />)}
                <div className={classes.grow} />
                {location.pathname === '/' && (
                <div className={classes.button}>
                    <IconButton component={Link} to="/cart" aria-label="Mostrar productos del carrito" color="inherit">
                        <Badge badgeContent={totalItems} color="secondary">
                            <ShoppingCart/>
                        </Badge>
                    </IconButton>
                </div> )}
            </Toolbar>            
        </AppBar>
    )
}

export default Navbar;
