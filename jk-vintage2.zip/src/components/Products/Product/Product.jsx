import React, { useState } from 'react';
import { Card, CardMedia, CardContent, CardActions, Typography, IconButton, Popover, Divider} from '@material-ui/core';
import { AddShoppingCart, HelpOutline } from '@material-ui/icons';
import useStyles from './styles';

const Product = ( { product, onAddToCart } ) => {
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    
    const handleClose = () => {
        setAnchorEl(null);
    };
    
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;

    return (
        <Card className={classes.root}>
            <CardMedia className={classes.media} image={product.media.source} title={product.name}/>
            <CardContent>
                <div className={classes.cardContent}>
                <Typography variant="h5" gutterBottom>
                    {product.name}
                </Typography>
                <Typography variant="h5">
                    {product.price.formatted_with_symbol}
                </Typography>
                </div>
                <Divider></Divider>
                <Typography dangerouslySetInnerHTML={{ __html: product.description }}  variant="body2" color="textSecondary"/>
            </CardContent>
            <CardActions disableSpacing className={classes.CardActions}>
                <div>
                <IconButton aria-describedby={id} onClick={handleClick}>
            <HelpOutline className={classes.helpIcon}/>
            </IconButton>
            <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
      >
        <Typography className={classes.popover} sx={{ p: 2 }}>Haz click en la imagen para saber más detalles del producto.</Typography>
      </Popover>
                </div>
                <IconButton aria-label="Añadir al carrito" onClick={() => onAddToCart(product.id, 1)}>
                    <AddShoppingCart className={classes.addCart}/>
                </IconButton>
            </CardActions>
        </Card>
    )
}

export default Product;
