import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
import Product from './Product/Product';
import useStyles from './styles';
import logo from '../../assets/logo.jpg';

const Products = ({ products, onAddToCart, valueSearch }) => {
    const classes = useStyles();
    const [filteredSearch, setFilteredSearch] = useState([]);

    useEffect(() => {
        setFilteredSearch(
            products.filter((product) => product.name.toLowerCase().includes(valueSearch.toLowerCase())
        )
        );
    }, [valueSearch,products]);
   

    return (
    <div>
        <div className="logoImage">
       {/* <img  src={logo} alt="Logo" ></img> */}
        </div>
    <main className={classes.content}>
        <div className={classes.toolbar}  />
        { valueSearch ? 
        <Grid container justifyContent="center" spacing={4}>
        {filteredSearch.map((product) => (
            <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
                <Product product={product} onAddToCart={onAddToCart}/>
            </Grid>
        ))}
        </Grid> :
        <div>
            <h1 className={classes.lastDrop}>ÚLTIMO DROP</h1>
        <Grid container justifyContent="center" spacing={4}>
        {products.map((product) => (
            <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
                <Product product={product} onAddToCart={onAddToCart}/>
            </Grid>
        ))}
        </Grid>
        </div>
}
    </main>    
    </div>
    )
}; 

export default Products;